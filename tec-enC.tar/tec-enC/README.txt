Version en langage C du projet "tec". 

1) Compilation
  dans le répertoire racine:
  % make

  Cette commande lance la compilation dans le repertoire tec 
  si nécessaire.

2) Execution
  dans le répertoire racine:
  % ./simple

  Le scénario simple.c sert d'exemple d'exécution (test de recette).
  

3) Source
  Dans le répertoire tec,  vous trouverez 
   - deux fichiers sources : autobus.c et ps_standard.c 
   - trois fichiers en-tête :
     + autobus.h et ps_standard.h déclarent les fonctions 
       de tec utilisées par le client (ici simple).
     + __internes.h déclare les fonctions internes de tec 
       que le client n'a pas à connaître et à utiliser.

     
  
